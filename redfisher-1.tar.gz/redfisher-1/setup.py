from distutils.core import setup

setup(
    name = "redfisher",
    version = "1",
    py_modules = ['redfisher']
    )
